laptop = {}
laptop.class_lib = {}
dofile(minetest.get_modpath('laptop')..'/themes.lua')
dofile(minetest.get_modpath('laptop')..'/block_devices.lua')
dofile(minetest.get_modpath('laptop')..'/app_fw.lua')
dofile(minetest.get_modpath('laptop')..'/mtos.lua')
dofile(minetest.get_modpath('laptop')..'/hardware_fw.lua')
dofile(minetest.get_modpath('laptop')..'/recipe_compat.lua')
dofile(minetest.get_modpath('laptop')..'/hardware_nodes.lua')
dofile(minetest.get_modpath('laptop')..'/craftitems.lua')
