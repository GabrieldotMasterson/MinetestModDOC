The Laptop mod is a group collaboration between Bell07, Toby109tt, veNext, Cross_over and Yours truly lol. We aim to make a working laptop inside of MineTest. There is multiple different computers to choose from and to use. There is multiple different apps to run on comupters There is multiple different media to store data There is multiple different themes to personalize computers

Apps Included So Far:

-- System -- 
System settings 
Removable media manager

-- Office -- 
Calculator
Sticky Notes
Email

-- Games -- 
TNTSweeper
Tetris

V.0.38
