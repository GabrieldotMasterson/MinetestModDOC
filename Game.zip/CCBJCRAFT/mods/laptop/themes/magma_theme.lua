laptop.register_theme("Magma", {
	desktop_background = "laptop_theme_magma_desktop_background.png",
	app_background = "laptop_theme_magma_app_background.png",
	major_button = "laptop_theme_magma_major_button.png",
	back_button = "laptop_theme_magma_back_button.png",
	exit_button = "laptop_theme_magma_exit_button.png",
	desktop_icon_button = "laptop_theme_magma_desktop_icon_button.png",
	os_min_version = '7.00',
})
