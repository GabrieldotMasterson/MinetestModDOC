laptop.register_theme("Fruit", {
	desktop_background = "laptop_theme_fruit_desktop_background.png",
	app_background = "laptop_theme_blue_app_background.png",
	os_min_version = '6.33',
})
