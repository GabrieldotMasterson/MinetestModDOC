dofile(minetest.get_modpath("tutorialmod").."/nodes.lua")
dofile(minetest.get_modpath("tutorialmod").."/tools.lua")
dofile(minetest.get_modpath("tutorialmod").."/ores.lua")